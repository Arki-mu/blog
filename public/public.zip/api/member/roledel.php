<?php 
include '../../conn.php';

$verify = true;
$msg = '';

if(isset($_GET['id']) && is_numeric($_GET['id'])){
    $id = $_GET['id'];
}else {
    $verify = false;
    $msg = 'id是必选参数';
}

if($verify){
   $sql="DELETE FROM hetu_role WHERE id=".$id;
   if(mysqli_query($conn,$sql)){
         $msg = '角色删除成功';
   }else{
        $verify = false;
        $msg = '角色删除失败';
   } 
}

echo json_encode(array('verify'=>$verify,'msg'=>$msg));
