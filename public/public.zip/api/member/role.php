<?php 
include '../../conn.php';
$verify = true;
$msg = '';
$role = [];

$sql =  "SELECT * FROM hetu_role WHERE 1=1 ";

if(isset($_GET['id'])){
    $sql.= "&& id=".$_GET['id'];
}

$result = mysqli_query($conn,$sql);
$role = mysqli_fetch_all($result,MYSQLI_ASSOC);


echo json_encode(array('verify'=>$verify,'msg'=>$msg,'role'=>$role));
