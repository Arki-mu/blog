<?php
include '../../conn.php';
$verify = true;
$msg = '';
$member = [];

$sql =  "SELECT * FROM hetu_member WHERE 1=1 ";

if (isset($_GET['id'])) {
    $sql .= "&& id=" . $_GET['id'];
}

$result = mysqli_query($conn, $sql);
$member = mysqli_fetch_all($result, MYSQLI_ASSOC);


echo json_encode(array('verify' => $verify, 'msg' => $msg, 'member' => $member));
