<?php
include '../../conn.php';
$verify = true;
$code = 200;
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['nickname']) && $_POST['nickname'] != "") {
        $nickname = $_POST['nickname'];
    } else {
        $nickname = '';
    }

    if (isset($_POST['roleid']) && is_numeric($_POST['roleid'])) {
        $roleid = $_POST['roleid'];
    } else {
        $roleid = 0;
    }

    if (isset($_POST['useravatar']) && is_numeric($_POST['useravatar'])) {
        $useravatar = $_POST['useravatar'];
    } else {
        $useravatar = 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png';
    }

    if (isset($_POST['phone']) && $_POST['phone'] != "") {
        $phone = $_POST['phone'];
    } else {
        $verify = false;
        $code = 401;
        $msg = '手机号码不能为空';
    }

    if (isset($_POST['email']) && $_POST['email'] != "") {
        $email = $_POST['email'];
    } else {
        $verify = false;
        $code = 401;
        $msg = '电子邮箱不能为空';
    }



    if (isset($_POST['password']) && $_POST['password'] != "") {
        $password = sha1($_POST['password']);
    } else {
        $verify = false;
        $code = 401;
        $msg = '初始密码不能为空';
    }

    if (isset($_POST['gender']) && $_POST['gender'] != "") {
        $gender = $_POST['gender'];
    } else {
        $gender = 0;
    }


    $registrationtime = strtotime(DATETIME);  //转时间戳

    if (isset($_POST['authority']) && $_POST['authority'] != "") {
        $authority = $_POST['authority'];
    } else {
        $authority = 9;
    }
} else {
    $verify = false;
    $code = 405;
    $msg = '资源请求出错，希望一个POST请求，结果来了一个' . $_SERVER['REQUEST_METHOD'] . '请求';
}


if ($verify) {
    $sql = "INSERT INTO hetu_member 
    (nickname, roleid, useravatar, phone, email, password, gender, registrationtime, authority) 
    VALUES 
    ('$nickname',$roleid,'$useravatar','$phone','$email','$password',$gender,$registrationtime,$authority)";
    if (mysqli_query($conn, $sql)) {
        $msg = '用户添加成功';
    } else {
        $verify = false;
        $code = 500;
        $msg = '用户添加失败';
    }
}

echo json_encode(array('verify' => $verify, 'code' => $code, 'msg' => $msg));
