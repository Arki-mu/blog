<?php 
include '../../conn.php';
$verify = true;
$msg = '';

if($_SERVER['REQUEST_METHOD'] != 'POST'){
    $verify = false;
    $msg = '请求方式必须是POST,而您给的是'.$_SERVER['REQUEST_METHOD'] ;
}   

if(isset($_POST['id']) && $_POST['id']!=""){
    $id = $_POST['id'];
}else {
    $verify = false;
    $msg = 'ID不能为空';
}



if(isset($_POST['rolename']) && $_POST['rolename']!=""){
    $rolename = $_POST['rolename'];
}else {
    $verify = false;
    $msg = '角色名称不能为空';
}

if (isset($_POST['authority']) && $_POST['authority'] != "") {
    if (ctype_digit($_POST['authority'])) {
        # code...
        $authority = $_POST['authority'];
    } else {
        $verify = false;
        $msg = '会员级别必须为0-9的数字';
    }
} else {
    $verify = false;
    $msg = '会员级别不能为空';
}

if(isset($_POST['roleauth']) && $_POST['roleauth']!=""){
    $roleauth = $_POST['roleauth'];
}else {
    $verify = false;
    $msg = '请至少选择一个权限';
}

if($verify){
    $sql="UPDATE hetu_role SET rolename='$rolename',authority='$authority',roleauth='$roleauth' WHERE id=".$id;;
   if(mysqli_query($conn,$sql)){
         $msg = '角色修改成功';
   }else{
        $verify = false;
        $msg = '角色修改失败';
   } 
}

echo json_encode(array('verify'=>$verify,'msg'=>$msg));
