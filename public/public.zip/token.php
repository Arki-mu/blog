<?php
$token = '123456';
if (isset($_GET['token']) && $_GET['token'] === $token) {
    echo json_encode(
        array('isverify' => true, 'msg' => '成功')
    );
} else {
    echo json_encode(
        array('isverify' => false, 'msg' => '失败')
    );
}
