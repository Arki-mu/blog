<?php
header("Content-type:text/html;charset=utf-8");

header("Access-Control-Allow-Origin:*");
header("Access-Control-Allow-Methods:GET, POST, OPTIONS, DELETE");
header("Access-Control-Allow-Headers:DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type, Accept-Language, Origin, Accept-Encoding");

define('DB_NAME', 'yunxiaodian.xyz');   //数据库名称
define('DB_USER', 'yunxiaodian.xyz');   //登录名
define('DB_PASSWORD', 'gmj5927');   //登录密码
define('DB_HOST', 'localhost');   //本地域名
define("DATETIME", date('Y-m-d H:i:s'));
$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
mysqli_query($conn, "set character set utf8");
mysqli_query($conn, "set names  utf8");

if ($conn->connect_error) {
    die('数据库连接失败');
}

// class Common
// {
//     public function conn()
//     {
//     }
// }

// $conn = new common();
